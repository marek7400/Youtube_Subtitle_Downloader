// Listener for when the user clicks the extension icon
chrome.action.onClicked.addListener((tab) => {
  // Ensure it's a YouTube video page
  if (tab.url && tab.url.includes("youtube.com/watch")) {
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js']
    });
  } else {
    // Show an alert if the user is on a wrong page
    chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => alert("This extension only works on YouTube video pages.")
    });
  }
});

// Listener for when a tab is updated (e.g., URL changes in a Single Page Application like YouTube)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  // We are interested only in URL changes.
  // We also check the tab URL to ensure it's a YouTube page, as changeInfo.url might not be a full URL initially.
  if (changeInfo.url && tab.url.includes("youtube.com/watch")) {
    
    // When the user navigates to a new video, we inject a small function
    // to find and remove our old dialog if it exists.
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: () => {
        const oldDialog = document.getElementById('subtitle-downloader-dialog');
        if (oldDialog) {
          oldDialog.remove();
          console.log('Subtitle Downloader: Old dialog removed automatically on navigation.');
        }
      }
    });
  }
});