

(() => {
    console.log('[Harvester] Uruchomiono skrypt contentowy.');
    const captured = window.__YT_SUBTITLE_HARVESTER_DATA__;
    
    if (!captured || (Object.keys(captured.fetch).length === 0 && Object.keys(captured.xhr).length === 0 && !captured.embedded)) {
        alert('Nie przechwycono jeszcze żadnych napisów. Odśwież stronę, włącz napisy w odtwarzaczu i spróbuj ponownie.*No subtitles have been captured yet. Refresh the page, enable subtitles in your player, and try again.');
        return;
    }

    const allCapturedSubs = { ...captured.fetch, ...captured.xhr };
    
    if (Object.keys(allCapturedSubs).length === 0 && captured.embedded) {
        console.log('[Harvester] Używam osadzonego URL do pobrania napisów...');
        const url = new URL(captured.embedded.url);
        url.searchParams.set('fmt', 'json3');
        
        fetch(url)
            .then(res => res.json())
            .then(data => {
                allCapturedSubs[captured.embedded.langCode] = {
                    data: data,
                    name: captured.embedded.name
                };
                displaySafeUI(allCapturedSubs);
            })
            .catch(err => {
                alert('Pobranie napisów z osadzonego URL nie powiodło się.');
                console.error(err);
            });
    } else {
        displaySafeUI(allCapturedSubs);
    }
})();

function displaySafeUI(capturedSubtitles) {
    document.getElementById('subtitle-harvester-dialog')?.remove();

    const playerResponse = window.ytInitialPlayerResponse;
    const videoTitle = playerResponse?.videoDetails?.title || 'video';
    
    const dialog = document.createElement('div');
    dialog.id = 'subtitle-harvester-dialog';
    dialog.style.cssText = `position: fixed; top: 10%; left: 50%; transform: translateX(-50%); width: 500px; max-width: 90vw; background: #282828; color: white; border-radius: 12px; z-index: 10001; font-family: sans-serif; display: flex; flex-direction: column;`;

    const header = document.createElement('div');
    header.style.cssText = `padding: 15px 20px; border-bottom: 1px solid #3e3e3e; display: flex; justify-content: space-between; align-items: center;`;
    
    const title = document.createElement('h2');
    title.textContent = 'Captured Subtitles';
    title.style.margin = '0';
    title.style.fontSize = '18px';

    const closeButton = document.createElement('button');
    closeButton.textContent = '×';
    closeButton.style.cssText = 'background:none; border:none; color:white; font-size:24px; cursor:pointer;';
    closeButton.onclick = () => dialog.remove();

    header.appendChild(title);
    header.appendChild(closeButton);
    dialog.appendChild(header);

    const listContainer = document.createElement('div');
    listContainer.style.cssText = `padding: 15px; max-height: 70vh; overflow-y: auto;`;

    for (const langCode in capturedSubtitles) {
        const capturedInfo = capturedSubtitles[langCode];
        const langName = capturedInfo.name || `Język (${langCode})`;
        const subtitleData = capturedInfo.data;

        const item = document.createElement('div');
        item.style.cssText = `display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #3e3e3e;`;

        const nameSpan = document.createElement('span');
        nameSpan.textContent = langName;
        nameSpan.style.fontSize = '16px';
        
        const downloadBtn = document.createElement('button');
        downloadBtn.textContent = 'DOWNLOAD .SRT';
        downloadBtn.style.cssText = `background: #3ea6ff; color: #0d0d0d; border: none; padding: 8px 14px; border-radius: 4px; cursor: pointer; font-weight: 500;`;
        downloadBtn.onclick = () => {
            const srt = formatToSrt(subtitleData);
            saveToFile(srt, `${videoTitle}_${langCode}.srt`);
        };

        item.appendChild(nameSpan);
        item.appendChild(downloadBtn);
        listContainer.appendChild(item);
    }
    
    dialog.appendChild(listContainer);
    document.body.appendChild(dialog);
}

// --- ZMIANA: Zmodyfikowana logika generowania napisów, aby zapobiec nakładaniu się ---

function formatToSrt(subData) {
    if (!subData || !subData.events) return '';

    const formatTime = (ms) => {
        const d = new Date(0);
        d.setMilliseconds(ms);
        return `${d.getUTCHours().toString().padStart(2, '0')}:${d.getUTCMinutes().toString().padStart(2, '0')}:${d.getUTCSeconds().toString().padStart(2, '0')},${d.getUTCMilliseconds().toString().padStart(3, '0')}`;
    };

    // 1. Filtrujemy puste napisy (tak jak poprzednio)
    const nonEmptyEvents = subData.events.filter(e =>
        e.segs && e.segs.map(s => s.utf8).join('').trim() !== ''
    );

    // 2. Mapujemy przefiltrowane napisy, ale z logiką zapobiegającą nakładaniu
    return nonEmptyEvents.map((currentEvent, i) => {
        const start = currentEvent.tStartMs;
        const text = currentEvent.segs.map(s => s.utf8).join('').trim();
        
        let end;
        const nextEvent = nonEmptyEvents[i + 1];

        if (nextEvent) {
            // Jeśli istnieje następny napis, bieżący kończy się dokładnie wtedy, gdy zaczyna się następny.
            end = nextEvent.tStartMs;
        } else {
            // Jeśli to ostatni napis, używamy jego oryginalnego czasu trwania.
            end = start + (currentEvent.dDurationMs || 2000); // 2 sekundy jako fallback
        }
        
        // Zabezpieczenie na wypadek, gdyby dane były nieprawidłowe i czas końca byłby przed czasem startu.
        if (end <= start) {
            end = start + 1000; // Daj mu przynajmniej sekundę
        }

        return `${i + 1}\n${formatTime(start)} --> ${formatTime(end)}\n${text}\n`;
    }).join('\n');
}

function saveToFile(content, filename) {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename.replace(/[<>:"/\\|?*]+/g, '_');
    a.click();
    URL.revokeObjectURL(a.href);
}
