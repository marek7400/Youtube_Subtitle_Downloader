

(() => {
  // --- ZMIANA: Zmieniamy strukturę, aby przechowywać obiekt z danymi i nazwą ---
  window.__YT_SUBTITLE_HARVESTER_DATA__ = {
    embedded: null,
    fetch: {},
    xhr: {}
  };
  console.log('[Harvester] Interceptor załadowany.');

  // --- Sprawdzenie danych osadzonych ---
  try {
    const embeddedTrack = window.ytInitialPlayerResponse?.captions?.playerCaptionsTracklistRenderer?.captionTracks[0];
    if (embeddedTrack?.baseUrl) {
        // --- ZMIANA: Zapisujemy obiekt z URL i nazwą dla osadzonych napisów ---
        window.__YT_SUBTITLE_HARVESTER_DATA__.embedded = {
            url: embeddedTrack.baseUrl,
            name: embeddedTrack.name.simpleText,
            langCode: embeddedTrack.languageCode
        };
        console.log('[Harvester] Znaleziono osadzone dane o napisach.');
    }
  } catch (e) { /* ignoruj błędy */ }
  
  // --- ZMIANA: Funkcja pomocnicza do pobierania nazwy i zapisywania danych ---
  function captureSubtitles(url, data) {
      const urlObj = new URL(url);
      const lang = urlObj.searchParams.get('tlang') || urlObj.searchParams.get('lang');
      if (!lang) return;

      const player = document.getElementById('movie_player');
      const currentTrack = player?.getCaptionTrack ? player.getCaptionTrack() : null;

      // Nazwę bierzemy z aktywnego śledzenia w odtwarzaczu - to jest najdokładniejsze źródło.
      // Sprawdzamy, czy kod języka się zgadza.
      const trackName = (currentTrack && (currentTrack.languageCode === lang || currentTrack.newASR === true)) 
          ? currentTrack.displayName 
          : `Język (${lang})`;

      console.log(`[Harvester] Przechwycono napisy dla języka: ${lang} (${trackName})`);
      
      // Zapisujemy w nowej strukturze
      return {
          lang,
          payload: {
              data,
              name: trackName
          }
      };
  }

  // --- Monkey-patch dla fetch ---
  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    const url = args[0] instanceof URL ? args[0].href : String(args[0]);
    if (url.includes('/api/timedtext')) {
      return originalFetch.apply(this, args).then(response => {
        const resClone = response.clone();
        resClone.json().then(data => {
            // --- ZMIANA: Używamy nowej funkcji ---
            const capture = captureSubtitles(url, data);
            if (capture) {
                window.__YT_SUBTITLE_HARVESTER_DATA__.fetch[capture.lang] = capture.payload;
            }
        });
        return response;
      });
    }
    return originalFetch.apply(this, args);
  };

  // --- Monkey-patch dla XMLHttpRequest ---
  const originalXhrOpen = XMLHttpRequest.prototype.open;
  const originalXhrSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    if (String(url).includes('/api/timedtext')) {
      this._isSubtitleRequest = true;
      this._requestUrl = url;
    }
    return originalXhrOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function(...args) {
    if (this._isSubtitleRequest) {
      this.addEventListener('load', () => {
        try {
          const data = JSON.parse(this.responseText);
          // --- ZMIANA: Używamy nowej funkcji ---
          const capture = captureSubtitles(this._requestUrl, data);
          if (capture) {
              window.__YT_SUBTITLE_HARVESTER_DATA__.xhr[capture.lang] = capture.payload;
          }
        } catch (e) { /* ignoruj błędy parsowania */ }
      });
    }
    return originalXhrSend.apply(this, args);
  };

})();

