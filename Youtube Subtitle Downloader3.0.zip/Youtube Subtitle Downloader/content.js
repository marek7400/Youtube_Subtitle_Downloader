
(() => {
    console.log('[Harvester] Content script loaded.');
    displaySafeUI(window.__YT_SUBTITLE_HARVESTER_DATA__ || {});
})();


function displaySafeUI(harvesterData) {
    document.getElementById('subtitle-harvester-dialog')?.remove();

    const player = document.getElementById('movie_player');
    // CHANGE: We use the player's method to get the current title,
    // which prevents using the old title after navigating to a new video.
    const videoTitle = player?.getVideoData()?.title || window.ytInitialPlayerResponse?.videoDetails?.title || 'video';
    
    const dialog = document.createElement('div');
    dialog.id = 'subtitle-harvester-dialog';
    dialog.style.cssText = `position: fixed; top: 10%; left: 50%; transform: translateX(-50%); width: 600px; max-width: 90vw; background: #282828; color: white; border-radius: 12px; z-index: 10001; font-family: sans-serif; display: flex; flex-direction: column; box-shadow: 0 10px 30px rgba(0,0,0,0.5);`;

    const header = document.createElement('div');
    header.style.cssText = `padding: 15px 20px; border-bottom: 1px solid #3e3e3e; display: flex; justify-content: space-between; align-items: center;`;
    
    const title = document.createElement('h2');
    title.textContent = 'Subtitle Downloader';
    title.style.margin = '0';
    title.style.fontSize = '18px';

    const closeButton = document.createElement('button');
    closeButton.textContent = '×';
    closeButton.style.cssText = 'background:none; border:none; color:white; font-size:24px; cursor:pointer;';
    closeButton.onclick = () => dialog.remove();

    header.appendChild(title);
    header.appendChild(closeButton);
    dialog.appendChild(header);

    const mainContainer = document.createElement('div');
    mainContainer.style.cssText = `padding: 0 20px 20px 20px; max-height: 70vh; overflow-y: auto;`;
    
    const allSubsHeader = document.createElement('h3');
    allSubsHeader.textContent = 'All available subtitles';
    allSubsHeader.style.cssText = 'margin: 20px 0 10px 0; font-size: 16px; color: #aaa;';
    mainContainer.appendChild(allSubsHeader);
    const allSubsContainer = document.createElement('div');
    mainContainer.appendChild(allSubsContainer);
    
    const allSubs = getAllAvailableSubtitles(window.ytInitialPlayerResponse);

    if (allSubs.length > 0) {
        allSubs.forEach(sub => {
            createListItem(allSubsContainer, sub.langName, videoTitle, sub.langCode, sub.sourceLangCode, harvesterData);
        });
    } else {
        const noSubsMsg = document.createElement('p');
        noSubsMsg.textContent = 'No subtitle list found in this video\'s data.';
        noSubsMsg.style.cssText = 'font-size: 14px; color: #ff8a80; padding: 10px 0; margin: 0;';
        allSubsContainer.appendChild(noSubsMsg);
    }

    dialog.appendChild(mainContainer);
    document.body.appendChild(dialog);
}

function getAllAvailableSubtitles(playerResponse) {
    const captionData = playerResponse?.captions?.playerCaptionsTracklistRenderer;
    if (!captionData) return [];

    const browserLang = navigator.language.split('-')[0];
    const allSubs = new Map();
    const sourceTrack = captionData.captionTracks?.find(track => track.isTranslatable);

    if (captionData.captionTracks) {
        captionData.captionTracks.forEach(track => {
            allSubs.set(track.languageCode, {
                langName: track.name.simpleText,
                langCode: track.languageCode,
                isAuto: track.kind === 'asr',
                sourceLangCode: null
            });
        });
    }

    if (sourceTrack && captionData.translationLanguages) {
        captionData.translationLanguages.forEach(lang => {
            const langCode = lang.languageCode;
            if (!allSubs.has(langCode)) {
                allSubs.set(langCode, {
                    langName: `${lang.languageName.simpleText} (auto-generated)`,
                    langCode: langCode,
                    isAuto: true,
                    sourceLangCode: sourceTrack.languageCode 
                });
            }
        });
    }

    const getScore = (sub) => {
        const isBrowserLang = sub.langCode === browserLang;
        if (isBrowserLang && !sub.isAuto) return 0;
        if (isBrowserLang && sub.isAuto) return 1;
        if (!isBrowserLang && !sub.isAuto) return 2;
        return 3;
    };
    
    return Array.from(allSubs.values()).sort((a, b) => {
        const scoreA = getScore(a);
        const scoreB = getScore(b);
        return scoreA !== scoreB ? scoreA - scoreB : a.langName.localeCompare(b.langName);
    });
}

function createListItem(container, langName, videoTitle, langCode, sourceLangCode, harvesterData) {
    const item = document.createElement('div');
    item.style.cssText = `display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px solid #3e3e3e;`;

    const nameSpan = document.createElement('span');
    nameSpan.textContent = langName;
    nameSpan.style.fontSize = '16px';
    
    const downloadBtn = document.createElement('button');
    downloadBtn.textContent = 'DOWNLOAD .SRT';
    downloadBtn.style.cssText = `background: #3ea6ff; color: #0d0d0d; border: none; padding: 8px 14px; border-radius: 4px; cursor: pointer; font-weight: 500;`;
    
    downloadBtn.onclick = () => {
        const player = document.getElementById('movie_player');
        const originalTrack = player?.getOption('captions', 'track') || {};

        downloadBtn.textContent = 'DOWNLOADING...';
        downloadBtn.disabled = true;

        const combinedKey = sourceLangCode ? `${langCode}(${sourceLangCode})` : langCode;
        const captured = harvesterData.fetch[combinedKey] || harvesterData.xhr[combinedKey];
        if (captured) {
            const srt = formatToSrt(captured.data);
            saveToFile(srt, `${videoTitle}_${langCode}.srt`);
            downloadBtn.textContent = 'DOWNLOAD .SRT';
            downloadBtn.disabled = false;
            return;
        }

        const trackOptions = {};
        if (sourceLangCode) {
            trackOptions.languageCode = sourceLangCode;
            trackOptions.translationLanguage = { languageCode: langCode };
        } else {
            trackOptions.languageCode = langCode;
        }
        player?.setOption('captions', 'track', trackOptions);

        let attempts = 0;
        const interval = setInterval(() => {
            attempts++;
            const newlyCaptured = harvesterData.fetch[combinedKey] || harvesterData.xhr[combinedKey];
            if (newlyCaptured) {
                clearInterval(interval);
                const srt = formatToSrt(newlyCaptured.data);
                saveToFile(srt, `${videoTitle}_${langCode}.srt`);
                downloadBtn.textContent = 'DOWNLOAD .SRT';
                downloadBtn.disabled = false;
                player?.setOption('captions', 'track', originalTrack);
            } else if (attempts > 50) {
                clearInterval(interval);
                alert(`Failed to capture subtitles for: ${langName}`);
                downloadBtn.textContent = 'ERROR';
                downloadBtn.style.backgroundColor = '#d93025';
                downloadBtn.disabled = false;
                player?.setOption('captions', 'track', originalTrack);
            }
        }, 100);
    };

    item.appendChild(nameSpan);
    item.appendChild(downloadBtn);
    container.appendChild(item);
}

function formatToSrt(subData) {
    if (!subData || !subData.events) return '';
    const formatTime = (ms) => {
        const d = new Date(0);
        d.setMilliseconds(ms);
        return `${d.getUTCHours().toString().padStart(2, '0')}:${d.getUTCMinutes().toString().padStart(2, '0')}:${d.getUTCSeconds().toString().padStart(2, '0')},${d.getUTCMilliseconds().toString().padStart(3, '0')}`;
    };
    const nonEmptyEvents = subData.events.filter(e => e.segs && e.segs.map(s => s.utf8).join('').trim() !== '' );
    return nonEmptyEvents.map((currentEvent, i) => {
        const start = currentEvent.tStartMs;
        const text = currentEvent.segs.map(s => s.utf8).join('').trim().replace(/\n/g, ' ');
        let end;
        const nextEvent = nonEmptyEvents[i + 1];
        if (nextEvent) {
            end = nextEvent.tStartMs;
        } else {
            end = start + (currentEvent.dDurationMs || 2000);
        }
        if (end <= start) {
            end = start + 1000;
        }
        return `${i + 1}\n${formatTime(start)} --> ${formatTime(end)}\n${text}\n`;
    }).join('\n');
}

function saveToFile(content, filename) {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename.replace(/[<>:"/\\|?*]+/g, '_');
    a.click();
    URL.revokeObjectURL(a.href);
}