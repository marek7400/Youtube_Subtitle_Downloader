
(() => {
  window.__YT_SUBTITLE_HARVESTER_DATA__ = {
    fetch: {},
    xhr: {}
  };
  console.log('[Harvester] Interceptor loaded.');
  
  function captureSubtitles(url, data) {
      const urlObj = new URL(url);
      const baseLang = urlObj.searchParams.get('lang');
      const tLang = urlObj.searchParams.get('tlang');

      if (!baseLang) return;

      const finalKey = tLang ? `${tLang}(${baseLang})` : baseLang;
      const displayLang = tLang || baseLang;

      const player = document.getElementById('movie_player');
      const currentTrack = player?.getCaptionTrack ? player.getCaptionTrack() : null;

      const trackName = (currentTrack && currentTrack.languageCode === displayLang) 
          ? currentTrack.displayName 
          : `Language (${displayLang})`;

      console.log(`[Harvester] Captured subtitles for key: ${finalKey} (${trackName})`);
      
      return {
          key: finalKey,
          payload: {
              data,
              name: trackName
          }
      };
  }

  const originalFetch = window.fetch;
  window.fetch = function(...args) {
    const url = args[0] instanceof URL ? args[0].href : String(args[0]);
    if (url.includes('/api/timedtext')) {
      return originalFetch.apply(this, args).then(response => {
        const resClone = response.clone();
        resClone.json().then(data => {
            const capture = captureSubtitles(url, data);
            if (capture) {
                window.__YT_SUBTITLE_HARVESTER_DATA__.fetch[capture.key] = capture.payload;
            }
        }).catch(e => {});
        return response;
      });
    }
    return originalFetch.apply(this, args);
  };

  const originalXhrOpen = XMLHttpRequest.prototype.open;
  const originalXhrSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    if (String(url).includes('/api/timedtext')) {
      this._isSubtitleRequest = true;
      this._requestUrl = url;
    }
    return originalXhrOpen.apply(this, [method, url, ...rest]);
  };

  XMLHttpRequest.prototype.send = function(...args) {
    if (this._isSubtitleRequest) {
      this.addEventListener('load', () => {
        try {
          const data = JSON.parse(this.responseText);
          const capture = captureSubtitles(this._requestUrl, data);
          if (capture) {
              window.__YT_SUBTITLE_HARVESTER_DATA__.xhr[capture.key] = capture.payload;
          }
        } catch (e) {}
      });
    }
    return originalXhrSend.apply(this, args);
  };

  // CHANGE: Added a listener for YouTube navigation.
  // This clears the captured subtitles when navigating to a new video.
  window.addEventListener('yt-navigate-finish', () => {
    console.log('[Harvester] New video navigation detected. Subtitle cache cleared.');
    window.__YT_SUBTITLE_HARVESTER_DATA__ = {
      fetch: {},
      xhr: {}
    };
  });

})();
